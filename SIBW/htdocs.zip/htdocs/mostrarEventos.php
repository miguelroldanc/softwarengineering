<?php
    require_once('scripts/bd.php');

    console.log("Hola");
    $eventos = obtenerEventos();
    $myJSON = json_encode($eventos);
    header('Content-Type: application/json');
    echo $myJSON;
?>